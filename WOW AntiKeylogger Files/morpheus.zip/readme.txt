KIWI MEDIA, Inc.
http://www.kiwi-media.com		
wonko@nulldevice.com

Shareware Pricing (email for current payment/contact information 
and invoicing if required)  All prices in US dollars.

Educational Use			$   0.00
(single) Personal Use		$  10.00
(multi/site) Business 		$  30.00

Commercial licensing is a special case, applying to design firms and
advertisers who will be using Kiwi Media products for external clients.

(single) Commercial 		$  15.00  
(multi/site) Commercial		$  contact 

Please note: Kiwi Media isn't a bunch of shareware facists.  We believe
that everyone should have access to quality software, but at the same time
we're trying to cover production costs.  So if you're and individual and 
paying for product is problematic, let us know and we'll see what we can work out.
If you're a multi-megabuck ad firm, you've got no excuse.

All Kiwi Media software is available for download from our web site.
Email with questions, comments, rants, raves, and so forth.



BORING BUT NECESSARY LEGAL STUFF--------------------------------------

USE OF THIS SOFTWARE CONSTITUES ACCEPTANCE OF THE FOLLOWING:

DISCLAIMER OF WARRANTY.  Software is
provided on an "AS IS" basis, without warranty of any
kind, including without limitation the warranties that
the Software is free of defects, merchantable, fit for a
particular purpose or non-infringing. The entire risk as
to the quality and performance of the Software is borne
by you. Should the Software prove defective in any
respect, you and not Licensor or its suppliers assume the
entire cost of any service and repair. This
disclaimer of warranty constitutes an essential part of
this Agreement. No use of the Software without payment of
license fees to Licensor is authorized hereunder except
under this Disclaimer or by arrangement with Licensor.

You may:

*  use the Software on any single computer; 
*  use the Software on a second computer so long as
   only one (1) copy is used at a time; 
*  use the Software on a network, provided that a
   license for multiple users is purchased;
*  use the software in any non-commercial documents
*  use the software in any comemrcial documents, provided
   that license for such use has been obtained from Kiwi Media. 
*  copy the Software for archival purposes, provided
   any copy must contain all of the original
   Software's proprietary notices; 
*  Duplicate and redistribute the software provided
   any copy must contain all of the original Software's
   proprietary notices and documents;

You may not:

*  permit other individuals to use the Software
   except under the terms listed above; 
*  permit concurrent use of the Software; 
*  modify, translate, reverse engineer, decompile,
   disassemble the Software (except for educational
   or instructional purposes or with express permission
   of Kiwi Media); 
*  copy the Software other than as specified above; 
*  rent, lease, grant a security interest in, or
   otherwise transfer rights to the Software; or
*  remove any proprietary notices or on the Software.

LIMITATION OF LIABILITY.  UNDER NO CIRCUMSTANCES AND
UNDER NO LEGAL THEORY, TORT, CONTRACT, OR OTHERWISE,
SHALL LICENSOR OR ITS SUPPLIERS OR RESELLERS BE LIABLE TO
YOU OR ANY OTHER PERSON FOR ANY INDIRECT, SPECIAL,
INCIDENTAL, OR CONSEQUENTIAL DAMAGES OF ANY CHARACTER
INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF
GOODWILL, WORK STOPPAGE, COMPUTER FAILURE OR MALFUNCTION,
OR ANY AND ALL OTHER COMMERCIAL DAMAGES OR LOSSES. IN NO
EVENT WILL LICENSOR BE LIABLE FOR ANY DAMAGES IN EXCESS
OF THE AMOUNT LICENSOR RECEIVED FROM YOU FOR A LICENSE TO
THE SOFTWARE, EVEN IF LICENSOR SHALL HAVE BEEN INFORMED
OF THE POSSIBILITY OF SUCH DAMAGES, OR FOR ANY CLAIM BY
ANY THIRD PARTY.  SOME JURISDICTIONS DO NOT
ALLOW THE EXCLUSION OR LIMITATION OF INCIDENTAL OR
CONSEQUENTIAL DAMAGES, SO THIS EXCLUSION AND LIMITATION
MAY NOT APPLY TO YOU.
