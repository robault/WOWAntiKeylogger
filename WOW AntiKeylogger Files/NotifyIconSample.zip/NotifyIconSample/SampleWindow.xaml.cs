using System;
using System.Windows;
using System.Windows.Input;

namespace NotifyIconSample
{
	/// <summary>
	/// Interaction logic for SampleWindow.xaml
	/// </summary>
	public partial class SampleWindow : Window
	{
		private WindowState lastWindowState;

		public SampleWindow()
		{
			this.InitializeComponent();
		}

		protected override void OnInitialized(EventArgs e)
		{
			base.OnInitialized(e);
			this.lastWindowState = WindowState;
			this.Hide();
		}

		protected override void OnStateChanged(EventArgs e)
		{
			if (this.WindowState == WindowState.Minimized)
			{
				this.Hide();
			}
			else
			{
				this.lastWindowState = this.WindowState;
			}
		}

		private void OnVisibilityClick(object sender, RoutedEventArgs e)
		{
			this.notifyIcon.Visibility = this.notifyIcon.Visibility == Visibility.Visible ?
				Visibility.Collapsed : Visibility.Visible;
		}

		private void OnBalloonClick(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.notifyIcon.BalloonTipText))
			{
				this.notifyIcon.ShowBalloonTip(2000);
			}
		}

		private void OnNotifyIconDoubleClick(object sender, MouseButtonEventArgs e)
		{
			if (e.ChangedButton == MouseButton.Left)
			{
				this.Show();
				this.WindowState = this.lastWindowState;
			}
		}

		private void OnOpenClick(object sender, RoutedEventArgs e)
		{
			this.Show();
			this.WindowState = this.lastWindowState;
		}

		private void OnExitClick(object sender, RoutedEventArgs e)
		{
			this.Close();
		}
	}
}