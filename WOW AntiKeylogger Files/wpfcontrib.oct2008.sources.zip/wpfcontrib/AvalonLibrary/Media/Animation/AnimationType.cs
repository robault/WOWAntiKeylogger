using System;

namespace Avalon.Windows.Media.Animation
{
    internal enum AnimationType : byte
    {
        Automatic = 0,
        By = 3,
        From = 1,
        FromBy = 5,
        FromTo = 4,
        To = 2
    }
}
